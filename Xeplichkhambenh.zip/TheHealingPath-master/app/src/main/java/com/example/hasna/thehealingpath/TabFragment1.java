package com.example.hasna.thehealingpath;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class TabFragment1 extends Fragment {

    DatabaseReference mref;
    int todaymoney = 0, day, month, year;
    ArrayList<String> patients = new ArrayList<>();
    public String key;
    FirebaseAuth auth;
    RelativeLayout rel;
    String uid;
    FragmentTransaction fTrans;
    ListView mlistview;
    FloatingActionButton fabb;
    ArrayList<DataModel> dataModels;
    CustomAdapter adapter;
    String strmonth;
    RelativeLayout rl;
    View view;
    Intent hello1;
    Globals g;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_patient, container, false);

        auth = FirebaseAuth.getInstance();
        uid = auth.getUid();
        Globals g = (Globals) getActivity().getApplication();
        day = getActivity().getIntent().getExtras().getInt("day");
        rel = view.findViewById(R.id.rlayout);
        mlistview = view.findViewById(R.id.lstview);
        fabb = view.findViewById(R.id.fabbtn);
        dataModels = new ArrayList<>();
        rl = view.findViewById(R.id.rlayout);
        g=(Globals)getActivity().getApplicationContext();

        adapter = new CustomAdapter(dataModels, getActivity().getApplicationContext());

        mlistview.setAdapter(adapter);

        month = getActivity().getIntent().getExtras().getInt("month");
        year = getActivity().getIntent().getExtras().getInt("year");

        String date = getActivity().getIntent().getExtras().getString("date");


        mref = FirebaseDatabase.getInstance().getReference().child(uid).child(Integer.toString(year)).child("m"+Integer.toString(month)).child("d"+Integer.toString(day));

        //mref = FirebaseDatabase.getInstance().getReference().child(uid).child(Integer.toString(year)).child("d"+Integer.toString(month)).child("d"+Integer.toString(day));
        mref.keepSynced(true);


        if (month == 1)
            strmonth = "Jan";
        else if (month == 2)
            strmonth = "Feb";
        else if (month == 3)
            strmonth = "Mar";
        else if (month == 4)
            strmonth = "Apr";
        else if (month == 5)
            strmonth = "May";
        else if (month == 6)
            strmonth = "June";
        else if (month == 7)
            strmonth = "July";
        else if (month == 8)
            strmonth = "Aug";
        else if (month == 9)
            strmonth = "Sept";
        else if (month == 10)
            strmonth = "Oct";
        else if (month == 11)
            strmonth = "Nov";
        else if (month == 12)
            strmonth = "Dec";


        mref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                if (!dataSnapshot.getKey().equals("Appointments")) {
                    String name = dataSnapshot.child("Name").getValue(String.class);
                    String med = dataSnapshot.child("Med").getValue(String.class);
                    Integer amt = dataSnapshot.child("Amt").getValue(Integer.class);
                    String ptype = dataSnapshot.child("Pay").getValue(String.class);
                    String pcheck = dataSnapshot.child("isPaid").getValue(String.class);
                    String pendingcheck = dataSnapshot.child("Pending").getValue(String.class);

                    if (TextUtils.isEmpty(pcheck))
                        pcheck = "1";
                    if (TextUtils.isEmpty(pendingcheck))
                        pendingcheck = "1";
                    if (pcheck.equals("1")) {
                        if (pendingcheck.equals("0")) {
                            dataModels.add(new DataModel(name, med, amt, ptype, pcheck, pendingcheck));
                        } else {
                            dataModels.add(new DataModel(name, med, amt, ptype, pcheck, pendingcheck));
                        }
                    } else
                        dataModels.add(new DataModel(name, med, amt, ptype, pcheck, pendingcheck));
                    adapter.notifyDataSetChanged();

                }

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                String value = dataSnapshot.child("Name").getValue(String.class);
                //patients.remove(value);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
                String value = dataSnapshot.child("Name").getValue(String.class);
                //patients.remove(value);

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });


        mlistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                DataModel dataModel = dataModels.get(position);
                String naam = dataModel.getName();

                mref.orderByChild("Name").equalTo(naam).addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot child : dataSnapshot.getChildren()) {
                            key = child.getKey();
                            Globals g = (Globals) getActivity().getApplicationContext();
                            g.setData(key);
                            String medname = dataSnapshot.child(key).child("Med").getValue(String.class);
                            String medamt = Integer.toString(dataSnapshot.child(key).child("Amt").getValue(Integer.class));
                            String ptype = dataSnapshot.child(key).child("Pay").getValue(String.class);
                            String ispaid = dataSnapshot.child(key).child("isPaid").getValue(String.class);
                            String namee = dataSnapshot.child(key).child("Name").getValue(String.class);
                            String pendamt = dataSnapshot.child(key).child("Pending").getValue(String.class);
                            openDispDialog(medname, medamt, ptype, ispaid, namee, pendamt, key);
                            //getActivity().finish();
                            //startActivity(getActivity().getIntent());
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(getActivity().getApplicationContext(), "Error", Toast.LENGTH_LONG).show();

                    }
                });
            }
        });

        fabb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });


        //long press
        mlistview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view,
                                           int position, long id) {
                DataModel dataModel = dataModels.get(position);
                String naam = dataModel.getName();

                mref.orderByChild("Name").equalTo(naam).addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot child : dataSnapshot.getChildren()) {
                            final String key = child.getKey();

                            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                            builder.setTitle("Delete Patient");
                            builder.setMessage("Are you sure?");
                            builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    mref.child(key).removeValue();

                                    Vibrator v = (Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE);
                                    v.vibrate(100);

                                    Intent hello = new Intent(getActivity(), PatAptActivity.class);
                                    hello.putExtra("day",day);
                                    hello.putExtra("month",month);
                                    hello.putExtra("year",year);
                                    getActivity().startActivity(hello);
                                    getActivity().finish();


                                    Toast.makeText(getActivity().getApplicationContext(), "Patient Deleted", Toast.LENGTH_LONG).show();

                                }
                            });
                            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                            AlertDialog alert = builder.create();
                            alert.show();



                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(getActivity().getApplicationContext(), "Connection Error", Toast.LENGTH_LONG).show();
                    }
                });
                return true;
            }
        });

        return view;
    }


    public void openDispDialog(String nameofmed,String amountmed, String paymenttype,String ispaid,String namee, String pendamt, String fkey){
        DispDialog dispDialog = new DispDialog ();
        dispDialog.m=nameofmed;
        dispDialog.am=amountmed;
        dispDialog.paymentt=paymenttype;
        dispDialog.p=ispaid;
        dispDialog.namee=namee;
        dispDialog.pend=pendamt;
        dispDialog.mkey=fkey;
        dispDialog.mo=month;
        dispDialog.ye=year;
        dispDialog.da=day;
        FragmentTransaction ft = getChildFragmentManager().beginTransaction();
        dispDialog.show(ft, "dialog");
    }

    public void openDialog() {

        ExampleDialog exDialog = new ExampleDialog();
        exDialog.mon=month;
        exDialog.yea=year;
        exDialog.dayy=day;
        exDialog.uidd=uid;
        FragmentTransaction ft = getChildFragmentManager().beginTransaction();
        exDialog.show(ft, "dialog");

    }

    public void getdispdialog(String paytype,int year1,int month1, int day1,String uid1,String kkey){

        DatabaseReference mref1 = FirebaseDatabase.getInstance().getReference().child(uid1).child(Integer.toString(year1)).child("m"+Integer.toString(month1)).child("d"+Integer.toString(day1));

        key=kkey;
        mref1.child(key).child("Pay").setValue(paytype);
        mref1.child(key).child("Pending").setValue("0");

        if(paytype.equals("Not Paid"))
            mref1.child(key).child("isPaid").setValue("0");
        else
            mref1.child(key).child("isPaid").setValue("1");

    }


    public void getdialog(String patname, String medname, int medamt, String payment, String isPaid, String pendingamt, int year1,int month1, int day1,String uidd) {

        DatabaseReference mref1 = FirebaseDatabase.getInstance().getReference().child(uidd).child(Integer.toString(year1)).child("m"+Integer.toString(month1)).child("d"+Integer.toString(day1));
        key=mref1.push().getKey();

        mref1.child(key).child("Name").setValue(patname);
        mref1.child(key).child("Med").setValue(medname);
        mref1.child(key).child("Amt").setValue(medamt);
        mref1.child(key).child("Pay").setValue(payment);
        mref1.child(key).child("isPaid").setValue(isPaid);
        if(pendingamt.equals("0")) {
            mref1.child(key).child("Pending").setValue("0");
        }
        else
        {
            mref1.child(key).child("Pending").setValue(Integer.toString(medamt - Integer.parseInt(pendingamt)));
        }
    }


}
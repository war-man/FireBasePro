package com.example.hasna.thehealingpath;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatDialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class disp_notpaid extends AppCompatDialogFragment {
    View view;
    ArrayAdapter arrayAdapter;
    int m,d,y;
    ArrayList<String> groupList1=new ArrayList<>();
    ArrayList<String> groupD1=new ArrayList<>();
    ArrayList<String> groupM1=new ArrayList<>();
    ArrayList<String> groupY1=new ArrayList<>();


    ListView mlistview;
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        final LayoutInflater inflater = getActivity().getLayoutInflater();
        view = inflater.inflate(R.layout.disp_notpaid, null);

        mlistview=view.findViewById(R.id.lstview);


        arrayAdapter= new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1,groupList1) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);

                TextView l = (TextView) view.findViewById(android.R.id.text1);
                l.setTextColor(Color.BLACK);

                return view;
            }


        };
        mlistview.setAdapter(arrayAdapter);
        //Log.e("hiii",m);

        mlistview.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                String naam = ((TextView)view).getText().toString();
                //Log.e("naam",""+);
                Intent hello=new Intent(getContext(),PatAptActivity.class);
                hello.putExtra("day",Integer.parseInt(groupD1.get(position)));
                hello.putExtra("month",Integer.parseInt(groupM1.get(position)));
                hello.putExtra("year",Integer.parseInt(groupY1.get(position)));
                startActivity(hello);
                }
            }
        );

        builder.setView(view)
                //.setTitle("Not paid")

                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }

                });
        return builder.create();

    }
}

package com.example.hasna.thehealingpath;

import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class CourierActivity extends AppCompatActivity {
    DatabaseReference mref;
    FirebaseAuth auth;
    FloatingActionButton fabb;
    ListView mlistview;
    RelativeLayout rel;
    String key,uidd;
    ArrayList<DataModelCourier> dataModels;
    CourierAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courier);
        auth = FirebaseAuth.getInstance();
        uidd = auth.getUid();
        dataModels = new ArrayList<>();

        rel = findViewById(R.id.rlayout);
        mlistview = findViewById(R.id.listview1);
        fabb = findViewById(R.id.fabbtn);

        adapter = new CourierAdapter(dataModels, getApplicationContext());
        mlistview.setAdapter(adapter);

        fabb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenDialog();
            }
        });

        mref = FirebaseDatabase.getInstance().getReference().child(uidd).child("Couriers");

        //mref = FirebaseDatabase.getInstance().getReference().child(uid).child(Integer.toString(year)).child("d"+Integer.toString(month)).child("d"+Integer.toString(day));
        mref.keepSynced(true);

        mref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                if (!dataSnapshot.getKey().equals("Appointments")) {
                    String name = dataSnapshot.child("Name").getValue(String.class);
                    String med = dataSnapshot.child("Med").getValue(String.class);
                    Integer day = dataSnapshot.child("Day").getValue(Integer.class);
                    Integer month = dataSnapshot.child("Month").getValue(Integer.class);
                    Integer year = dataSnapshot.child("Year").getValue(Integer.class);
                    String date = Integer.toString(day)+'/'+Integer.toString(month)+'/'+Integer.toString(year);
                    dataModels.add(new DataModelCourier(name, med, date));
                    adapter.notifyDataSetChanged();

                }

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                String value = dataSnapshot.child("Name").getValue(String.class);
                //patients.remove(value);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
                String value = dataSnapshot.child("Name").getValue(String.class);
                //patients.remove(value);

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });
    }


    public void OpenDialog() {
        disp_courier dispDialog1 = new disp_courier();
        dispDialog1.show(getSupportFragmentManager(), "disp_courier");
    }

    public void getdialog(String patname, String medname, int medamt, String payment, String isPaid, String pendingamt, int year1,int month1, int day1, String chkaddflag) {
        auth = FirebaseAuth.getInstance();

        uidd = auth.getUid();

        Log.e("ua","ok"+uidd);
        DatabaseReference mref1 = FirebaseDatabase.getInstance().getReference().child(uidd).child("Couriers");
        key=mref1.push().getKey();
        mref1.child(key).child("Name").setValue(patname);
        mref1.child(key).child("Med").setValue(medname);
        mref1.child(key).child("Day").setValue(day1);
        mref1.child(key).child("Month").setValue(month1);
        mref1.child(key).child("Year").setValue(year1);

        if(chkaddflag=="1"){
            DatabaseReference mref2 = FirebaseDatabase.getInstance().getReference().child(uidd).child(Integer.toString(year1)).child("m"+Integer.toString(month1)).child("d"+Integer.toString(day1));
            key=mref2.push().getKey();

            mref2.child(key).child("Name").setValue(patname);
            mref2.child(key).child("Med").setValue(medname);
            mref2.child(key).child("Amt").setValue(medamt);
            mref2.child(key).child("Pay").setValue(payment);
            mref2.child(key).child("isPaid").setValue(isPaid);
            if(pendingamt.equals("0")) {
                mref2.child(key).child("Pending").setValue("0");
            }
            else
            {
                mref2.child(key).child("Pending").setValue(Integer.toString(medamt - Integer.parseInt(pendingamt)));
            }
        }



    }
}

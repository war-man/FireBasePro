package com.example.hasna.thehealingpath;

import android.Manifest;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.provider.ContactsContract;
import android.support.design.widget.Snackbar;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.telephony.SmsManager;
import android.text.InputType;
import android.text.TextPaint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.net.URLEncoder;
import java.util.ArrayList;

import static android.app.Activity.RESULT_OK;

public class DispDialogApt extends DialogFragment {
    TextView pname,phno;
    ImageView imgcall,imgmsg,imgwhat;
    DatabaseReference mref,uref;
    String timee,uid;
    FirebaseAuth auth;
    View view;
    String patnameapt,phone,conf,hour,min,key;
    int month,year,day;
    String newmin,searnum;
    String smstosend;
    String contactID;
    Uri uriContact;
    public String un;
    public final int PICK_CONTACT = 2015;

    String newnostr="";

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        view = inflater.inflate(R.layout.disp_dialog_apt, null);
        auth = FirebaseAuth.getInstance();
        uid = auth.getUid();
        uref = FirebaseDatabase.getInstance().getReference().child(uid);
        mref = FirebaseDatabase.getInstance().getReference().child(uid).child(Integer.toString(year)).child("m"+Integer.toString(month)).child("d"+Integer.toString(day)).child("Appointments");

        pname = view.findViewById(R.id.pna);
        phno = view.findViewById(R.id.phn);
        imgcall = view.findViewById(R.id.call);
        imgmsg = view.findViewById(R.id.msg);
        imgwhat=view.findViewById(R.id.whatsappp);


        pname.setText(patnameapt);
        phno.setText(phone);

        if(min.equals("0"))
           newmin="00";
        else
            newmin=min;

        timee=hour+":"+newmin;

        imgwhat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uref.child("Username").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        final String username=snapshot.getValue(String.class);

                        if(phone.equals("No Number Provided")) {
                            Snackbar snackbar = Snackbar.make(view, "Error: Click the Number field to edit Contact Number", Snackbar.LENGTH_LONG);
                            snackbar.show();
                        }
                        else {
                            if(phone.length()==13)
                                phone=phone.substring(3,13);
                            if(phone.length()==12)
                                phone=phone.substring(2,12);
                            smstosend = "Your appointment with Dr." + username + " is confirmed for " + timee + " today.";
                            PackageManager packageManager = getActivity().getPackageManager();
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            try {
                                mref.child(key).child("Confirmed").setValue("1");
                                smstosend = "Your appointment with Dr." + username + " is confirmed for " + timee + " today.";
                                String url = "https://api.whatsapp.com/send?phone=+91" + phone + "&text=" + URLEncoder.encode(smstosend, "UTF-8");
                                i.setPackage("com.whatsapp");
                                i.setData(Uri.parse(url));
                                if (i.resolveActivity(packageManager) != null) {
                                    getActivity().startActivity(i);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });
            }

        });



        phno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());

                final EditText newno = new EditText(getContext());
                newno.setInputType(InputType.TYPE_CLASS_NUMBER);
                newno.setHint("Contact Number..");

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT);
                newno.setLayoutParams(lp);
                alertDialog.setView(newno);
                alertDialog.setPositiveButton("Confirm",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                newnostr=newno.getText().toString();
                                if(newnostr.equals(""))
                                    newnostr=phone;
                                else {
                                    phno.setText(newnostr);
                                    phone=newnostr;
                                    phno.setTextColor(Color.RED);
                                    mref.child(key).child("Phone").setValue(newnostr);
                                    Snackbar snackbar = Snackbar.make(view,"Number updated",Snackbar.LENGTH_LONG);
                                    snackbar.show();
                                }


                            }
                        });

                alertDialog.setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });

                alertDialog.setNeutralButton("Search",
                        new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int id)
                            {
                                Intent i = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
                                startActivityForResult(i, PICK_CONTACT);
                            }
                        });

                alertDialog.show();
            }
        });


        imgmsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                uref.child("Username").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                       final String username=snapshot.getValue(String.class);

                smstosend="Your appointment with Dr."+username+" is confirmed for "+timee+" today.";
                        if(phone.equals("No Number Provided")) {
                            Snackbar snackbar = Snackbar.make(view, "Error: Click the Number field to edit Contact Number", Snackbar.LENGTH_LONG);
                            snackbar.show();
                        }
                        else {
                            AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
                            final EditText smstemp = new EditText(getContext());
                            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.MATCH_PARENT);
                            smstemp.setLayoutParams(lp);
                            //smstemp.setPadding(50,0,0,0);
                            smstemp.setText(smstosend);
                            alertDialog.setView(smstemp);

                            alertDialog.setPositiveButton("Yes",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {

                                            SmsManager sms = SmsManager.getDefault();
                                            smstosend = smstemp.getText().toString().trim();


                                            sms.sendTextMessage(phone, null, smstosend, null, null);
                                            mref.child(key).child("Confirmed").setValue("1");
                                            Snackbar snackbar = Snackbar.make(view, "Message sent to " + patnameapt, Snackbar.LENGTH_LONG);
                                            snackbar.show();


                                        }
                                    });

                            alertDialog.setNegativeButton("No",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.cancel();
                                        }
                                    });
                            alertDialog.setTitle("Confirm Appointment?");
                            alertDialog.show();
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });



            }

        });

        imgcall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(phone.equals("No Number Provided")) {
                    Snackbar snackbar = Snackbar.make(view, "Error: Click the Number field to edit Contact Number", Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
                else {
                    String uri = "tel:" +phone;
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    intent.setData(Uri.parse(uri));
                    startActivity(intent);
                }
            }
        });


        builder.setView(view)
                .setTitle(timee)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Intent hello = new Intent(getActivity(), PatAptActivity.class);
                        hello.putExtra("day",day);
                        hello.putExtra("month",month);
                        hello.putExtra("year",year);
                        getActivity().startActivity(hello);
                        getActivity().finish();

                    }

                });
        return builder.create();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PICK_CONTACT && resultCode == RESULT_OK) {
            Uri contactUri = data.getData();
            Cursor cursor = getActivity().getContentResolver().query(contactUri, null, null, null, null);
            cursor.moveToFirst();
            int column = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);

            Log.e("fffff", cursor.getString(column));
            searnum=cursor.getString(column);
            phno.setText(searnum);
            phone=searnum;
            phno.setTextColor(Color.RED);

            String tempp=phone;

            phone="";
            for(int i=0;i<tempp.length();i++){

                if(tempp.charAt(i)>='0' && tempp.charAt(i)<='9')
                {
                    phone=phone+tempp.charAt(i);
                }
            }


            mref.child(key).child("Phone").setValue(phone);
            Snackbar snackbar = Snackbar.make(view,"Number updated",Snackbar.LENGTH_LONG);
            snackbar.show();
        }
    }



}

package com.example.hasna.thehealingpath;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DispDialog extends DialogFragment {

    TextView mnamem,mamtm,mpend;
    RadioButton mpaid,mnotpaid;
    //DispDialogListener dispDialogListener;
    String newmedstr="",payment,namee,k,paymentt,m,am,p,pend;
    ToggleButton paidsw;
    String mkey,posbtn,newamtstr="";
    RadioButton mcash,mcard,mneft,mpaytm;
    DatabaseReference mref;
    String uid;
    FirebaseAuth auth;
    int mo,ye,da;
    View view;

    int newamtint,newamount;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder= new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        view=inflater.inflate(R.layout.disp_dialog,null);
        auth=FirebaseAuth.getInstance();
        uid=auth.getUid();
        mref= FirebaseDatabase.getInstance().getReference().child(uid).child(Integer.toString(ye)).child("m"+Integer.toString(mo)).child("d"+Integer.toString(da));


        mcard=view.findViewById(R.id.card);
        Log.e("Hasu",Integer.toString(ye));
        mcash=view.findViewById(R.id.cash);
        mneft=view.findViewById(R.id.neft);
        mpaytm=view.findViewById(R.id.paytm);
        mpend=view.findViewById(R.id.txtpend);

        mnamem=view.findViewById(R.id.medname);
        paidsw=view.findViewById(R.id.tog);
        mamtm=view.findViewById(R.id.medamt);

        if(pend.equals("0")) {
            mpend.setText("");
            posbtn="OK";
        }
        else {
            mpend.setText("Pending: Rs." + pend);
            posbtn="PAID";
        }

        mnamem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());

                final EditText newmed = new EditText(getContext());
                newmed.setInputType(InputType.TYPE_CLASS_TEXT|
                        InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
                newmed.setHint("New Medicine Name..");

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT);
                newmed.setLayoutParams(lp);
                alertDialog.setView(newmed);
                alertDialog.setPositiveButton("Confirm",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                newmedstr=newmed.getText().toString();
                                if(newmedstr.equals(""))
                                    newmedstr=m;
                                else {
                                    mnamem.setText(newmedstr);
                                    mnamem.setTextColor(Color.RED);
                                    mref.child(mkey).child("Med").setValue(newmedstr);
                                    Snackbar snackbar = Snackbar.make(view,"Medicine name updated",Snackbar.LENGTH_LONG);
                                    snackbar.show();
                                }


                            }
                        });

                alertDialog.setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });

                alertDialog.show();
            }
        });

        mamtm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());


                final EditText newamt = new EditText(getContext());
                newamt.setHint("New Amount..");
                newamt.setInputType(InputType.TYPE_CLASS_NUMBER);

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT);
                newamt.setLayoutParams(lp);
                alertDialog.setView(newamt);
                alertDialog.setPositiveButton("Confirm",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                newamtstr=newamt.getText().toString();
                                if(newamtstr.equals(""))
                                    newamtint=Integer.parseInt(am);
                                else {
                                    newamtint = Integer.parseInt(newamt.getText().toString());
                                    mamtm.setText("Rs. " + newamtstr);
                                    mref.child(mkey).child("Amt").setValue(newamtint);
                                    mamtm.setTextColor(Color.RED);
                                    Snackbar snackbar = Snackbar.make(view,"Amount updated",Snackbar.LENGTH_LONG);
                                    snackbar.show();
                                }
                            }
                        });

                alertDialog.setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });

                alertDialog.show();
            }
        });


        builder.setView(view)
                .setTitle(namee)
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                })
                .setPositiveButton(posbtn, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (mcard.isChecked())
                            payment = "Card";
                        else if (mcash.isChecked())
                            payment = "Cash";
                        else if (mneft.isChecked())
                            payment = "NEFT";
                        else if (mpaytm.isChecked())
                            payment = "PayTM";
                        else
                            payment="Not Paid";
                        String newpendamt="0";

                        if(newamtstr.equals("")) {
                            newamtint = Integer.parseInt(am);

                        }

                        if(newmedstr.equals(""))
                            newmedstr=m;

                        new TabFragment1().getdispdialog(payment,ye,mo,da,uid,mkey);
                        Intent hello = new Intent(getActivity(), PatAptActivity.class);
                        hello.putExtra("day",da);
                        hello.putExtra("month",mo);
                        hello.putExtra("year",ye);
                        getActivity().startActivity(hello);
                        getActivity().finish();

                    }

                });

        if(p.equals("0")) {
            paidsw.setChecked(false);
            mcard.setEnabled(true);
            mcash.setEnabled(true);
            mneft.setEnabled(true);
            mpaytm.setEnabled(true);
            mcard.setSelected(false);
            mcash.setSelected(false);
            mpaytm.setSelected(false);
            mneft.setSelected(false);
        }
        else{
            paidsw.setChecked(true);
            mcard.setEnabled(false);
            mcash.setEnabled(false);
            mneft.setEnabled(false);
            mpaytm.setEnabled(false);
            if(paymentt.equals("Card")){
                mcard.setEnabled(true);
                mcard.setSelected(true);}
            else if(paymentt.equals("Cash")) {
                mcash.setEnabled(true);
                mcash.setSelected(true);
            }
            else if(paymentt.equals("PayTM")) {
                mpaytm.setEnabled(true);
                mpaytm.setSelected(true);
            }
            else if(paymentt.equals("NEFT")) {
                mneft.setEnabled(true);
                mneft.setSelected(true);
            }
        }
        mnamem.setText(m);
        mamtm.setText("Rs. "+am);
        if(paymentt.equals("Card"))
            mcard.setChecked(true);
        else if(paymentt.equals("Cash"))
            mcash.setChecked(true);
        else if(paymentt.equals("PayTM"))
            mpaytm.setChecked(true);
        else if(paymentt.equals("NEFT"))
            mneft.setChecked(true);

        return builder.create();
    }

}
package com.example.hasna.thehealingpath;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONObject;


public class UserDetails extends AppCompatActivity {
    FirebaseAuth auth;
    Button backup;
    TextView em,ui;
    JSONObject objuser,objmonth,objday;
    DatabaseReference mref;
    String day,month;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);

        auth=FirebaseAuth.getInstance();
        em=findViewById(R.id.email);
        ui=findViewById(R.id.uidd);
        auth=FirebaseAuth.getInstance();
        String uid=auth.getUid();
        mref = FirebaseDatabase.getInstance().getReference().child(uid);


        em.setText(auth.getCurrentUser().getEmail());
        ui.setText("UID: "+auth.getUid());

    }
}

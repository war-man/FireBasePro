package com.example.hasna.thehealingpath;

public class DataModelApt {

    String name;
    String phnum;
    String conf;
    String min;
    String time;

    public DataModelApt(String name, String phnum, String time, String conf, String min) {
        this.name=name;
        this.phnum=phnum;
        this.time=time;
        this.conf=conf;
        this.min=min;
    }

    public String getName() {
        return name;
    }

    public String getNum() {
        return phnum;
    }
    public String getMin() {
        return min;
    }

    public String getTime() {
        return time;
    }

    public String getConf() {
        return conf;
    }


}
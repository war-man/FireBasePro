package com.example.hasna.thehealingpath;

import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class PatAptActivity extends AppCompatActivity {

    int todaymoney=0,day,month,year;
    String strmonth;
    RelativeLayout rel;
    FirebaseAuth auth;
    ViewPager viewPager;
    String uid;
    DatabaseReference mref;
    PagerAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.patapt);
        day=getIntent().getExtras().getInt("day");
        month=getIntent().getExtras().getInt("month");
        year=getIntent().getExtras().getInt("year");

        auth = FirebaseAuth.getInstance();
        uid=auth.getUid();

        mref= FirebaseDatabase.getInstance().getReference().child(uid).child(Integer.toString(year)).child("m"+Integer.toString(month)).child("d"+Integer.toString(day));
        mref.keepSynced(true);
        viewPager = (ViewPager) findViewById(R.id.pager);
        rel=findViewById(R.id.main_layout);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        if(month==1)
            strmonth="Jan";
        else if(month==2)
            strmonth="Feb";
        else if(month==3)
            strmonth="Mar";
        else if(month==4)
            strmonth="Apr";
        else if(month==5)
            strmonth="May";
        else if(month==6)
            strmonth="June";
        else if(month==7)
            strmonth="July";
        else if(month==8)
            strmonth="Aug";
        else if(month==9)
            strmonth="Sept";
        else if(month==10)
            strmonth="Oct";
        else if(month==11)
            strmonth="Nov";
        else if(month==12)
            strmonth="Dec";

        toolbar.setTitle(Integer.toString(day)+"-"+strmonth+"-"+Integer.toString(year));

        setSupportActionBar(toolbar);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        tabLayout.addTab(tabLayout.newTab().setText("Patients"));
        tabLayout.addTab(tabLayout.newTab().setText("Appointments"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);


        adapter = new PagerAdapter
                (getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.example_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId())
        {

            case R.id.showmoney:
                calcmoney();
                todaymoney=0;
                break;

        }
        return super.onOptionsItemSelected(item);
    }
    public void calcmoney(){

        mref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot child: dataSnapshot.getChildren()) {
                    String key = child.getKey();
                    if (!key.equals("Appointments")) {
                        String checkpaid = dataSnapshot.child(key).child("isPaid").getValue(String.class);
                        int medamt = dataSnapshot.child(key).child("Amt").getValue(Integer.class);
                        if (checkpaid.equals("1"))
                            todaymoney = todaymoney + medamt;
                    }
                }

                Snackbar snackbar = Snackbar.make(rel, "Today: Rs. " + todaymoney, Snackbar.LENGTH_LONG);
                snackbar.show();
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),"Connection Error", Toast.LENGTH_LONG).show();
            }

        });
    }




}
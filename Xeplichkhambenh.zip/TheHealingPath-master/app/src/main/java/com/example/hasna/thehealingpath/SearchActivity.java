package com.example.hasna.thehealingpath;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {

    EditText sname;
    DatabaseReference mref;
    Button sear;
    int flag=0;
    String str;
    TextView mres;
    Toolbar toolbar;
    ArrayList<String> dates=new ArrayList<>();
    ListView lst;
    String uid;
    FirebaseAuth auth;
    String searchname;
    RelativeLayout rll;
    Snackbar snackbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        searchname=getIntent().getExtras().getString("sname");
        auth=FirebaseAuth.getInstance();
        uid=auth.getUid();
        mref = FirebaseDatabase.getInstance().getReference().child(uid);

        lst = findViewById(R.id.listview1);
        rll=findViewById(R.id.rellay);

        final ArrayAdapter<String> arrayAdapter= new ArrayAdapter<String>(this,android.R.layout.simple_expandable_list_item_1,dates);
        lst.setAdapter(arrayAdapter);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        dates.clear();
        str=searchname;


                mref.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for(DataSnapshot childy : dataSnapshot.getChildren()){
                            String year= childy.getKey();

                        for (DataSnapshot child : dataSnapshot.child(year).getChildren()) {
                            String month = child.getKey();

                            for (DataSnapshot child1 : dataSnapshot.child(year).child(month).getChildren()) {
                                String day = child1.getKey();

                                for (DataSnapshot child2 : dataSnapshot.child(year).child(month).child(day).getChildren()) {
                                    String key = child2.getKey();
                                    if (!key.equals("Appointments")) {

                                        String namecheck = child2.child("Name").getValue(String.class);

                                        if (namecheck.toLowerCase().equals(str.toLowerCase())) {
                                            toolbar.setTitle("Results for: " + namecheck);

                                            str = namecheck;

                                            dates.add(day.substring(1,day.length()) + "/" + month.substring(1,month.length()) + "/" + year);
                                            arrayAdapter.notifyDataSetChanged();
                                            flag = 1;
                                        } else if (namecheck.toLowerCase().contains(str.toLowerCase()) && namecheck.toLowerCase().startsWith(str.toLowerCase())) {
                                            toolbar.setTitle("Results for: " + namecheck);

                                            str = namecheck;

                                            dates.add(day.substring(1,day.length()) + "/" + month.substring(1,month.length()) + "/" + year);
                                            arrayAdapter.notifyDataSetChanged();
                                            flag = 1;
                                        }
                                    }
                                }

                            }
                        }
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(), "Connection Error", Toast.LENGTH_LONG).show();
                    }
                });


        lst.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                String datesel = ((TextView)view).getText().toString();
                int i=0;
                String intentday="";
                String intentmonth="";
                String intentyear="";

                while(datesel.charAt(i)!='/'){
                    intentday=intentday+datesel.charAt(i);
                    i++;
                }
                i++;
                while(datesel.charAt(i)!='/'){
                    intentmonth=intentmonth+datesel.charAt(i);
                    i++;
                }
                i++;
                while(i<datesel.length()){
                    intentyear=intentyear+datesel.charAt(i);
                    i++;
                }

                Intent hello=new Intent(getBaseContext(),PatAptActivity.class);
                hello.putExtra("day",Integer.parseInt(intentday));
                hello.putExtra("month",Integer.parseInt(intentmonth));
                hello.putExtra("year",Integer.parseInt(intentyear));
                startActivity(hello);



            }
        });

    }

}

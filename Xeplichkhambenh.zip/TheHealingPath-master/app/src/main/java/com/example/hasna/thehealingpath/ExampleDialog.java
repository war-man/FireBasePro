package com.example.hasna.thehealingpath;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ExampleDialog extends DialogFragment {

    EditText p_name,m_name,amt,pending;
    String uidd,payment,isPaid;
    String pendingamt;
    RadioGroup paytypegrp;
    CheckBox mpend;
    RadioButton mnot,mcash,mcard,mneft,mpaytm;
    RelativeLayout rlay;
    View view;
    int yea,mon,dayy;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder= new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        view=inflater.inflate(R.layout.layout_dialog,null);
        rlay=view.findViewById(R.id.lay);

        pending = new EditText(getActivity());
        pending.setHint("Amount Paid by Patient..");
        pending.setInputType(InputType.TYPE_CLASS_NUMBER);
        final RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.BELOW, R.id.pend);

        p_name=view.findViewById(R.id.pname);

        m_name=view.findViewById(R.id.mname);
        mcard=view.findViewById(R.id.card);
        mcash=view.findViewById(R.id.cash);
        mnot=view.findViewById(R.id.not);
        mpend=view.findViewById(R.id.pend);
        paytypegrp=view.findViewById(R.id.paytype);

        mneft=view.findViewById(R.id.neft);
        mpaytm=view.findViewById(R.id.paytm);
        amt=view.findViewById(R.id.mamt);
        mcash.setChecked(true);
        mpend.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                if(isChecked)
                {
                    rlay.addView(pending,params);
                }
                else{
                    pending.setText("");
                    rlay.removeView(pending);
                }

            }
        });

        paytypegrp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // checkedId is the RadioButton selected
                if(checkedId==R.id.not) {
                    mpend.setEnabled(false);
                    rlay.removeView(pending);
                    mpend.setChecked(false);
                }
                else {
                    mpend.setEnabled(true);
                }
            }
        });
        builder.setView(view)
                .setTitle("Add New Patient")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                })
                .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String patname=p_name.getText().toString().trim();
                        String medname=m_name.getText().toString().trim();
                        pendingamt="0";
                        String medd=amt.getText().toString().trim();
                        if (mcard.isChecked()) {
                            payment = "Card";
                            isPaid="1";
                        }
                        else if (mcash.isChecked()) {
                            payment = "Cash";
                            isPaid="1";

                        }
                        else if (mneft.isChecked()) {
                            payment = "NEFT";
                            isPaid="1";

                        }
                        else if (mpaytm.isChecked()) {
                            payment = "PayTM";
                            isPaid="1";

                        }
                        else if(mnot.isChecked()) {
                            payment = "Not Paid";
                            isPaid="0";

                        }

                        if(mpend.isChecked())
                        {
                            pendingamt=pending.getText().toString().trim();
                            Log.e("Hasu",pendingamt);
                        }
                        else
                        {
                            pendingamt="0";
                        }

                        if(patname.equals("") || medname.equals("") || medd.equals("")) {
                            Toast.makeText(getActivity(),"Empty Field",Toast.LENGTH_LONG).show();
                        }
                        else {
                            int medamt=Integer.parseInt(medd);

                            Vibrator v = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
                            v.vibrate(100);

                            new TabFragment1().getdialog(patname, medname, medamt, payment, isPaid, pendingamt, yea, mon, dayy, uidd);
                            Intent hello = new Intent(getActivity(), PatAptActivity.class);
                            hello.putExtra("day", dayy);
                            hello.putExtra("month", mon);
                            hello.putExtra("year", yea);
                            getActivity().startActivity(hello);
                            getActivity().finish();
                        }

                    }
                });

        return builder.create();
    }


}
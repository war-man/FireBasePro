package com.example.hasna.thehealingpath;

public class DataModelCourier {

    String name;
    String med;
    String date;

    public DataModelCourier(String name, String med, String date) {
        this.name=name;
        this.med=med;
        this.date=date;
    }

    public String getName() {
        return name;
    }

    public String getMed() {
        return med;
    }

    public String getDate() {
        return date;
    }

}
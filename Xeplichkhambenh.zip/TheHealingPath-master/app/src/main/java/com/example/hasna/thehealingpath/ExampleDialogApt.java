package com.example.hasna.thehealingpath;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.provider.ContactsContract;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

import static android.app.Activity.RESULT_OK;

public class ExampleDialogApt extends DialogFragment {

    EditText papt,phno;
    String uidd,searnum="555";
    int hour1,min1;
    RelativeLayout rlay;
    Button timebtn,tempbtn;
    View view;
    int yea,mon,dayy;
    public final int PICK_CONTACT = 2015;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder= new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        view=inflater.inflate(R.layout.layout_dialog_apt,null);
        rlay=view.findViewById(R.id.lay);
        papt=view.findViewById(R.id.aptname);
        phno=view.findViewById(R.id.pno);
        timebtn=view.findViewById(R.id.tbtn);
        tempbtn=view.findViewById(R.id.button);

        timebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);
                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(getActivity(), new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        hour1=selectedHour;
                        min1=selectedMinute;
                    }
                }, hour, minute, true);//Yes 24 hour time
                mTimePicker.setTitle("Select Time");
                mTimePicker.show();
            }
        });

        tempbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
                startActivityForResult(i, PICK_CONTACT);
            }
        });


        builder.setView(view)
                .setTitle("Add New Appointment")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                })
                .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String pnameapt=papt.getText().toString().trim();
                        String phone=phno.getText().toString().trim();

                        if(pnameapt.equals(""))
                            Toast.makeText(getActivity(),"Enter Patient Name",Toast.LENGTH_SHORT).show();
                        else {
                            Vibrator v = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
                            v.vibrate(100);
                            if(phone.equals(""))
                                phone="No Number Provided";
                            new TabFragment2().getdialogapt(pnameapt, phone, hour1, min1, yea, mon, dayy, uidd);
                            Intent hello = new Intent(getActivity(), PatAptActivity.class);
                            hello.putExtra("day", dayy);
                            hello.putExtra("month", mon);
                            hello.putExtra("year", yea);
                            getActivity().startActivity(hello);
                            getActivity().finish();
                        }

                    }
                });

        return builder.create();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PICK_CONTACT && resultCode == RESULT_OK) {
            Uri contactUri = data.getData();
            Cursor cursor = getActivity().getContentResolver().query(contactUri, null, null, null, null);
            cursor.moveToFirst();
            int column = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);

            Log.e("fffff", cursor.getString(column));
            searnum=cursor.getString(column);
            phno.setText(searnum);
        }
    }


}
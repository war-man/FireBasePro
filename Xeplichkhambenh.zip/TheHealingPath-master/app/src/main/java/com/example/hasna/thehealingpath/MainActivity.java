package com.example.hasna.thehealingpath;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;

import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateLongClickListener;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;
import com.prolificinteractive.materialcalendarview.OnMonthChangedListener;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    MaterialCalendarView calendarView;
    public int smonth, syear, gmonth, gyear, gday;
    String key, longstrmonth;
    RelativeLayout rel;
    int notpaid, todaymoney, mYear, mDay, mMonth, longmonth, longyear, longday;
    DatabaseReference mref;
    ArrayList<String> groupList;
    ArrayList<String> groupD;
    ArrayList<String> groupM;
    ArrayList<String> groupY;
    ArrayList<String> patsearch;

    private static final int PERMISSION_SEND_SMS = 123;
    private static final int PERMISSION_READ_CONTACTS = 124;

    String y, sname;
    int todaymoney1;
    private static FirebaseDatabase firebaseDatabase;
    Snackbar snackbar1;
    EditText searchtxt;
    disp_notpaid d;
    disp_searchpat s;
    String uid;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (firebaseDatabase == null) {
            firebaseDatabase = FirebaseDatabase.getInstance();
            firebaseDatabase.setPersistenceEnabled(true);
        }
        //FirebaseDatabase.getInstance().setPersistenceEnabled(true);

        auth = FirebaseAuth.getInstance();
        Log.e("okok", auth.getUid());
        uid = auth.getUid();
        Toolbar toolbar = findViewById(R.id.toolbar1);
        setSupportActionBar(toolbar);
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        searchtxt = findViewById(R.id.searchtext);
        rel = findViewById(R.id.rlay);
        calendarView = findViewById(R.id.calendarView);
        calendarView.setDateSelected(c.getTime(), true);
        calendarView.setSelectionColor(Color.parseColor("#FD8469"));
        smonth = c.get(Calendar.MONTH) + 1;
        syear = c.get(Calendar.YEAR);

        calendarView.setOnMonthChangedListener(new OnMonthChangedListener() {
            @Override
            public void onMonthChanged(MaterialCalendarView materialCalendarView, CalendarDay calendarDay) {
                syear = calendarDay.getYear();
                smonth = calendarDay.getMonth() + 1;
                calendarView.clearSelection();
                calendarView.setDateSelected(c.getTime(), true);
            }
        });

        //mref= FirebaseDatabase.getInstance().getReference().child("Patients");
        mref = FirebaseDatabase.getInstance().getReference().child(uid);

        mref.keepSynced(true);


        calendarView.setOnDateLongClickListener(new OnDateLongClickListener() {
            @Override
            public void onDateLongClick(@NonNull MaterialCalendarView materialCalendarView, @NonNull CalendarDay calendarDay) {
                todaymoney1 = 0;
                longmonth = calendarDay.getMonth() + 1;
                longyear = calendarDay.getYear();
                longday = calendarDay.getDay();
                calcmoney1();
            }
        });

        calendarView.setOnDateChangedListener(new OnDateSelectedListener() {
            @Override
            public void onDateSelected(@NonNull MaterialCalendarView materialCalendarView, @NonNull CalendarDay calendarDay, boolean b) {
                Log.e("dok", Integer.toString(calendarDay.getMonth()));

                gmonth = calendarDay.getMonth() + 1;
                gyear = calendarDay.getYear();
                gday = calendarDay.getDay();
                String date = Integer.toString(gday) + Integer.toString(gmonth) + Integer.toString(gyear);
                Intent hello = new Intent(getBaseContext(), PatAptActivity.class);
                hello.putExtra("date", date);
                hello.putExtra("day", gday);
                hello.putExtra("month", gmonth);
                hello.putExtra("year", gyear);
                startActivity(hello);
            }
        });


        searchtxt.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;
                s = new disp_searchpat();
                patsearch = new ArrayList<String>();

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (event.getRawX() >= (searchtxt.getRight() - searchtxt.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        // your action here
                        sname = searchtxt.getText().toString();
                        if (sname.equals("")) {
                            snackbar1 = Snackbar.make(rel, "Empty Text box", Snackbar.LENGTH_LONG);
                            snackbar1.show();
                        } else {

                            mref.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    for(DataSnapshot childy : dataSnapshot.getChildren()){
                                        String year= childy.getKey();

                                        for (DataSnapshot child : dataSnapshot.child(year).getChildren()) {
                                            String month = child.getKey();

                                            for (DataSnapshot child1 : dataSnapshot.child(year).child(month).getChildren()) {
                                                String day = child1.getKey();

                                                for (DataSnapshot child2 : dataSnapshot.child(year).child(month).child(day).getChildren()) {
                                                    String key = child2.getKey();
                                                    if (!key.equals("Appointments")) {

                                                        String namecheck = child2.child("Name").getValue(String.class);
                                                        if(namecheck.toLowerCase().contains(sname.toLowerCase())) {
                                                            if (!patsearch.contains(namecheck)) {
                                                                patsearch.add(namecheck);
                                                            }
                                                        }

                                                        /*if (namecheck.toLowerCase().equals(str.toLowerCase())) {
                                                            toolbar.setTitle("Results for: " + namecheck);

                                                            str = namecheck;

                                                            dates.add(day.substring(1,day.length()) + "/" + month.substring(1,month.length()) + "/" + year);
                                                            arrayAdapter.notifyDataSetChanged();
                                                            flag = 1;
                                                        } else if (namecheck.toLowerCase().contains(str.toLowerCase()) && namecheck.toLowerCase().startsWith(str.toLowerCase())) {
                                                            toolbar.setTitle("Results for: " + namecheck);

                                                            str = namecheck;

                                                            dates.add(day.substring(1,day.length()) + "/" + month.substring(1,month.length()) + "/" + year);
                                                            arrayAdapter.notifyDataSetChanged();
                                                            flag = 1;
                                                        }*/
                                                    }
                                                }

                                            }
                                        }
                                    }

                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {
                                    Toast.makeText(getApplicationContext(), "Connection Error", Toast.LENGTH_LONG).show();
                                }
                            });

                            if (patsearch.size() != 0) {
                                Bundle args = new Bundle();
                                args.putSerializable("patsearch", patsearch);
                                s.setArguments(args);
                            }

                            openDispDialogSearch();

                            /*Intent hello = new Intent(getBaseContext(), SearchActivity.class);
                            hello.putExtra("sname", sname);
                            startActivity(hello);*/
                        }

                        return true;
                    }
                }
                return false;
            }
        });

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
                Log.e("ffff","explain");
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        PERMISSION_SEND_SMS);
            }
        }
        else
        {
            Log.e("fffff","Granted");
        }

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.READ_CONTACTS)) {
                Log.e("ffff","explain");
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_CONTACTS},
                        PERMISSION_READ_CONTACTS);
            }
        }
        else
        {
            Log.e("fffff","Granted");
        }
    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_toolbar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
           // case R.id.permission1:

                /*if (ContextCompat.checkSelfPermission(this,
                        Manifest.permission.SEND_SMS)
                        != PackageManager.PERMISSION_GRANTED) {

                    // Should we show an explanation?
                    if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                            Manifest.permission.SEND_SMS)) {
                        Log.e("ffff","explain");
                        // Show an expanation to the user *asynchronously* -- don't block
                        // this thread waiting for the user's response! After the user
                        // sees the explanation, try again to request the permission.

                    } else {

                        // No explanation needed, we can request the permission.

                        ActivityCompat.requestPermissions(this,
                                new String[]{Manifest.permission.SEND_SMS},
                                PERMISSION_SEND_SMS);

                        // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                        // app-defined int constant. The callback method gets the
                        // result of the request.
                    }
                }
                else
                {
                    Log.e("fffff","Granted");
                    // Permission already granted ... This is where you can continue your further business logic...
                }*/

                //break;

            case R.id.showmoneymonth:

                todaymoney = 0;
                notpaid = 0;
                d = new disp_notpaid();
                groupList = new ArrayList<String>();
                groupD = new ArrayList<String>();
                groupM = new ArrayList<String>();
                groupY = new ArrayList<String>();
                mref.child(Integer.toString(syear)).child("m"+Integer.toString(smonth)).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override

                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot child : dataSnapshot.getChildren()) {
                            String key = child.getKey();
                            for (DataSnapshot child1 : dataSnapshot.child(key).getChildren()) {
                                String key1 = child1.getKey();
                                String checkpaid = child1.child("isPaid").getValue(String.class);
                                String namenotpaid = child1.child("Name").getValue(String.class);
                                int medamt = child1.child("Amt").getValue(Integer.class);

                                if (checkpaid.equals("1")) {
                                    todaymoney = todaymoney + medamt;
                                } else {
                                    notpaid++;
                                    Log.e("aaa",key.substring(1,key.length()));
                                    groupD.add(key.substring(1,key.length()));
                                    groupM.add(Integer.toString(smonth));
                                    groupY.add(Integer.toString(syear));
                                    groupList.add(namenotpaid + "     " + key.substring(1,key.length()) + "/" + Integer.toString(smonth) + "/" + Integer.toString(syear));
                                }
                            }
                        }
                        if (groupList.size() != 0) {
                            Bundle args = new Bundle();
                            args.putSerializable("groupList", groupList);
                            d.setArguments(args);
                        }


                        if (smonth == 1) {
                            if (notpaid != 0) {
                                Snackbar snackbar = Snackbar.make(rel, "January: Rs. " + todaymoney + ", " + notpaid + " not paid", Snackbar.LENGTH_LONG)
                                        .setAction("Show", new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                openDispDialog("hiiiahfsodjgndo;n");
                                            }
                                        });
                                snackbar.show();
                            } else {
                                Snackbar snackbar = Snackbar.make(rel, "January: Rs. " + todaymoney, Snackbar.LENGTH_LONG);
                                snackbar.show();
                            }
                        } else if (smonth == 2) {
                            if (notpaid != 0) {
                                Snackbar snackbar = Snackbar.make(rel, "February: Rs. " + todaymoney + ", " + notpaid + " not paid", Snackbar.LENGTH_LONG)
                                        .setAction("Show", new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                openDispDialog("hiiiahfsodjgndo;n");
                                            }
                                        });
                                snackbar.show();
                            } else {
                                Snackbar snackbar = Snackbar.make(rel, "February: Rs. " + todaymoney, Snackbar.LENGTH_LONG);
                                snackbar.show();
                            }
                        }
                        if (smonth == 3) {
                            if (notpaid != 0) {
                                Snackbar snackbar = Snackbar.make(rel, "March: Rs. " + todaymoney + ", " + notpaid + " not paid", Snackbar.LENGTH_LONG)
                                        .setAction("Show", new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                openDispDialog("hiiiahfsodjgndo;n");
                                            }
                                        });
                                snackbar.show();
                            } else {
                                Snackbar snackbar = Snackbar.make(rel, "March: Rs. " + todaymoney, Snackbar.LENGTH_LONG);
                                snackbar.show();
                            }
                        } else if (smonth == 4) {
                            if (notpaid != 0) {
                                Snackbar snackbar = Snackbar.make(rel, "April: Rs. " + todaymoney + ", " + notpaid + " not paid", Snackbar.LENGTH_LONG)
                                        .setAction("Show", new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                openDispDialog("hiiiahfsodjgndo;n");
                                            }
                                        });
                                snackbar.show();
                            } else {
                                Snackbar snackbar = Snackbar.make(rel, "April: Rs. " + todaymoney, Snackbar.LENGTH_LONG);
                                snackbar.show();
                            }
                        }
                        if (smonth == 5) {
                            if (notpaid != 0) {
                                Snackbar snackbar = Snackbar.make(rel, "May: Rs. " + todaymoney + ", " + notpaid + " not paid", Snackbar.LENGTH_LONG)
                                        .setAction("Show", new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                openDispDialog("hiiiahfsodjgndo;n");
                                            }
                                        });
                                snackbar.show();
                            } else {
                                Snackbar snackbar = Snackbar.make(rel, "May: Rs. " + todaymoney, Snackbar.LENGTH_LONG);
                                snackbar.show();
                            }
                        } else if (smonth == 6) {
                            if (notpaid != 0) {
                                Snackbar snackbar = Snackbar.make(rel, "June: Rs. " + todaymoney + ", " + notpaid + " not paid", Snackbar.LENGTH_LONG)
                                        .setAction("Show", new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                openDispDialog("hiiiahfsodjgndo;n");
                                            }
                                        });
                                snackbar.show();
                            } else {
                                Snackbar snackbar = Snackbar.make(rel, "June: Rs. " + todaymoney, Snackbar.LENGTH_LONG);
                                snackbar.show();
                            }
                        }
                        if (smonth == 7) {
                            if (notpaid != 0) {
                                Snackbar snackbar = Snackbar.make(rel, "July: Rs. " + todaymoney + ", " + notpaid + " not paid", Snackbar.LENGTH_LONG)
                                        .setAction("Show", new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                openDispDialog("hiiiahfsodjgndo;n");
                                            }
                                        });
                                snackbar.show();
                            } else {
                                Snackbar snackbar = Snackbar.make(rel, "July: Rs. " + todaymoney, Snackbar.LENGTH_LONG);
                                snackbar.show();
                            }
                        } else if (smonth == 8) {
                            if (notpaid != 0) {
                                Snackbar snackbar = Snackbar.make(rel, "August: Rs. " + todaymoney + ", " + notpaid + " not paid", Snackbar.LENGTH_LONG)
                                        .setAction("Show", new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                openDispDialog("hiiiahfsodjgndo;n");
                                            }
                                        });
                                snackbar.show();
                            } else {
                                Snackbar snackbar = Snackbar.make(rel, "August: Rs. " + todaymoney, Snackbar.LENGTH_LONG);
                                snackbar.show();
                            }
                        }

                        if (smonth == 9) {
                            if (notpaid != 0) {
                                Snackbar snackbar = Snackbar.make(rel, "September: Rs. " + todaymoney + ", " + notpaid + " not paid", Snackbar.LENGTH_LONG)
                                        .setAction("Show", new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                openDispDialog("hiiiahfsodjgndo;n");
                                            }
                                        });
                                snackbar.show();
                            } else {
                                Snackbar snackbar = Snackbar.make(rel, "September: Rs. " + todaymoney, Snackbar.LENGTH_LONG);
                                snackbar.show();
                            }
                        } else if (smonth == 10) {
                            if (notpaid != 0) {
                                Snackbar snackbar = Snackbar.make(rel, "October: Rs. " + todaymoney + ", " + notpaid + " not paid", Snackbar.LENGTH_LONG)
                                        .setAction("Show", new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                openDispDialog("hiiiahfsodjgndo;n");
                                            }
                                        });
                                snackbar.show();
                            } else {
                                Snackbar snackbar = Snackbar.make(rel, "October: Rs. " + todaymoney, Snackbar.LENGTH_LONG);
                                snackbar.show();
                            }
                        }
                        if (smonth == 11) {
                            if (notpaid != 0) {
                                Snackbar snackbar = Snackbar.make(rel, "November: Rs. " + todaymoney + ", " + notpaid + " not paid", Snackbar.LENGTH_LONG)
                                        .setAction("Show", new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                openDispDialog("hiiiahfsodjgndo;n");
                                            }
                                        });
                                snackbar.show();
                            } else {
                                Snackbar snackbar = Snackbar.make(rel, "November: Rs. " + todaymoney, Snackbar.LENGTH_LONG);
                                snackbar.show();
                            }
                        } else if (smonth == 12) {
                            if (notpaid != 0) {
                                Snackbar snackbar = Snackbar.make(rel, "December: Rs. " + todaymoney + ", " + notpaid + " not paid", Snackbar.LENGTH_LONG)
                                        .setAction("Show", new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                openDispDialog("hiiiahfsodjgndo;n");
                                            }
                                        });
                                snackbar.show();
                            } else {
                                Snackbar snackbar = Snackbar.make(rel, "December: Rs. " + todaymoney, Snackbar.LENGTH_LONG);
                                snackbar.show();
                            }
                        }

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(), "Connection Error", Toast.LENGTH_LONG).show();
                    }
                });
                break;
            case R.id.showcourier:
                Intent hello2 = new Intent(getBaseContext(), CourierActivity.class);
                startActivity(hello2);
                break;
            case R.id.signout:
                auth.signOut();
                Intent hello = new Intent(getBaseContext(), LoginActivity.class);
                startActivity(hello);
                finish();
                break;
            case R.id.details:
                Intent hello1 = new Intent(getBaseContext(), UserDetails.class);
                startActivity(hello1);
        }
        return super.onOptionsItemSelected(item);
    }

    public void openDispDialog(String nameofmed) {
        disp_notpaid dispDialog1 = new disp_notpaid();
        dispDialog1.groupList1 = groupList;
        dispDialog1.groupD1 = groupD;
        dispDialog1.groupM1 = groupM;
        dispDialog1.groupY1 = groupY;
        dispDialog1.show(getSupportFragmentManager(), "disp_notpaid");
    }

    public void openDispDialogSearch() {
        disp_searchpat dispDialog1 = new disp_searchpat();
        dispDialog1.groupList1 = patsearch;
        dispDialog1.show(getSupportFragmentManager(), "disp_searchpat");
    }

    public void calcmoney1() {

        mref.child(Integer.toString(longyear)).child(Integer.toString(longmonth)).child(Integer.toString(longday)).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    String key = child.getKey();
                    String checkpaid = dataSnapshot.child(key).child("isPaid").getValue(String.class);
                    int medamt = dataSnapshot.child(key).child("Amt").getValue(Integer.class);
                    if (checkpaid.equals("1"))
                        todaymoney = todaymoney + medamt;
                }
                if (longmonth == 1)
                    longstrmonth = "Jan";
                else if (longmonth == 2)
                    longstrmonth = "Feb";
                else if (longmonth == 3)
                    longstrmonth = "Mar";
                else if (longmonth == 4)
                    longstrmonth = "Apr";
                else if (longmonth == 5)
                    longstrmonth = "May";
                else if (longmonth == 6)
                    longstrmonth = "June";
                else if (longmonth == 7)
                    longstrmonth = "July";
                else if (longmonth == 8)
                    longstrmonth = "Aug";
                else if (longmonth == 9)
                    longstrmonth = "Sept";
                else if (longmonth == 10)
                    longstrmonth = "Oct";
                else if (longmonth == 11)
                    longstrmonth = "Nov";
                else if (longmonth == 12)
                    longstrmonth = "Dec";
                Snackbar snackbar = Snackbar.make(rel, longday + "-" + longstrmonth + "-" + longyear + ": Rs. " + todaymoney, Snackbar.LENGTH_SHORT);
                snackbar.show();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "Connection Error", Toast.LENGTH_LONG).show();
            }

        });
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_SEND_SMS: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.e("fffff", "go");
                } else {
                    Log.e("fffff", "no go");

                }
            }
        }
    }
}

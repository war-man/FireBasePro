package com.example.hasna.thehealingpath;

import android.app.Application;

public class Globals extends Application {
    private String data="";

    public String getData(){
        return this.data;
    }
    public void setData(String d){
        this.data=d;
    }


}
package com.example.hasna.thehealingpath;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatDialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class disp_searchpat extends AppCompatDialogFragment {
    View view;
    ArrayAdapter arrayAdapter;
    int m,d,y;
    ArrayList<String> groupList1=new ArrayList<>();
    
    ListView mlistview;
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        final LayoutInflater inflater = getActivity().getLayoutInflater();
        view = inflater.inflate(R.layout.disp_notpaid, null);

        mlistview=view.findViewById(R.id.lstview);

        arrayAdapter= new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1,groupList1) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);

                TextView l = (TextView) view.findViewById(android.R.id.text1);
                l.setTextColor(Color.BLACK);

                return view;
            }


        };
        mlistview.setAdapter(arrayAdapter);

        mlistview.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                String naam = ((TextView)view).getText().toString();
                Intent hello=new Intent(getContext(),SearchActivity.class);
                hello.putExtra("sname", naam);
                startActivity(hello);
                }

            }
        );


        builder.setView(view)
                //.setTitle("Not paid")

                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }

                });
        return builder.create();

    }
}

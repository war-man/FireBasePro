package com.example.hasna.thehealingpath;

public class DataModel {

    String name;
    String med;
    String ptype;
    Integer amount;
    String isPaid;
    String pending;

    public DataModel(String name, String med, Integer amount, String ptype, String isPaid, String pending) {
        this.name=name;
        this.med=med;
        this.ptype=ptype;
        this.amount=amount;
        this.isPaid=isPaid;
        this.pending=pending;

    }

    public String getName() {
        return name;
    }

    public String getMed() {
        return med;
    }

    public String getPtype() {
        return ptype;
    }

    public Integer getAmount() {
        return amount;
    }
    public String getisPaid() {
        return isPaid;
    }
    public String getPending() {
        return pending;
    }

}
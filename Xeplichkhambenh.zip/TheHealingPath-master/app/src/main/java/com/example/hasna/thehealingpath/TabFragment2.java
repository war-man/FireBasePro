package com.example.hasna.thehealingpath;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Vibrator;
import android.provider.ContactsContract;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.content.Intent;

import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class TabFragment2 extends Fragment
{
    ArrayList<String> apt = new ArrayList<>();
    FloatingActionButton fab;
    FirebaseAuth auth;
    String uid;
    DatabaseReference mref;
    String key;
    int day, month, year;
    ListView lv;
    ArrayList<DataModelApt> dataModelsApt;
    CustomAdapterApt adapter;
    RelativeLayout rlay;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab_fragment_2, container, false);

        auth = FirebaseAuth.getInstance();
        uid = auth.getUid();

        fab = view.findViewById(R.id.fabbtnapt);
        day=getActivity().getIntent().getExtras().getInt("day");
        month=getActivity().getIntent().getExtras().getInt("month");
        year=getActivity().getIntent().getExtras().getInt("year");
        rlay = view.findViewById(R.id.rlayy);
        lv=view.findViewById(R.id.lstviewapt);

        mref = FirebaseDatabase.getInstance().getReference().child(uid).child(Integer.toString(year)).child("m"+Integer.toString(month)).child("d"+Integer.toString(day)).child("Appointments");
        mref.keepSynced(true);

        dataModelsApt = new ArrayList<>();
        adapter = new CustomAdapterApt(dataModelsApt, getActivity().getApplicationContext());

        lv.setAdapter(adapter);

        mref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                    String name = dataSnapshot.child("Name").getValue(String.class);
                    String phnum = dataSnapshot.child("Phone").getValue(String.class);
                    String conf = dataSnapshot.child("Confirmed").getValue(String.class);
                    String min = dataSnapshot.child("Minute").getValue(String.class);
                    String hour = dataSnapshot.child("Hour").getValue(String.class);
                    String time=hour+":"+min;
                    if (TextUtils.isEmpty(conf))
                        conf = "1";
                    if (TextUtils.isEmpty(min))
                        min= "1";
                    if(conf.equals("1") || min.equals("1")) {
                        dataModelsApt.add(new DataModelApt(name, phnum, time, conf, min));
                    }
                    else{
                        dataModelsApt.add(new DataModelApt(name, phnum, time, conf, min));
                    }
                adapter.notifyDataSetChanged();

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                String value = dataSnapshot.child("Name").getValue(String.class);
                //patients.remove(value);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
                String value = dataSnapshot.child("Name").getValue(String.class);
                //patients.remove(value);

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });

        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view,
                                           int position, long id) {
                DataModelApt dataModel = dataModelsApt.get(position);
                String naam = dataModel.getName();

                mref.orderByChild("Name").equalTo(naam).addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot child : dataSnapshot.getChildren()) {
                            final String key = child.getKey();

                            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                            builder.setTitle("Delete Appointment");
                            builder.setMessage("Are you sure?");
                            builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    mref.child(key).removeValue();

                                    Vibrator v = (Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE);
                                    v.vibrate(100);

                                    Intent hello = new Intent(getActivity(), PatAptActivity.class);
                                    hello.putExtra("day",day);
                                    hello.putExtra("month",month);
                                    hello.putExtra("year",year);
                                    getActivity().startActivity(hello);
                                    getActivity().finish();


                                    Toast.makeText(getActivity().getApplicationContext(), "Appointment Deleted", Toast.LENGTH_LONG).show();

                                }
                            });
                            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                            AlertDialog alert = builder.create();
                            alert.show();



                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(getActivity().getApplicationContext(), "Connection Error", Toast.LENGTH_LONG).show();
                    }
                });
                return true;
            }
        });
         lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                DataModelApt dataModel = dataModelsApt.get(position);
                String naam = dataModel.getName();

                mref.orderByChild("Name").equalTo(naam).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot child : dataSnapshot.getChildren()) {
                            key = child.getKey();
                            Globals g = (Globals) getActivity().getApplicationContext();
                            g.setData(key);
                            String name = dataSnapshot.child(key).child("Name").getValue(String.class);
                            String phnum = dataSnapshot.child(key).child("Phone").getValue(String.class);
                            String conf = dataSnapshot.child(key).child("Confirmed").getValue(String.class);
                            String min = dataSnapshot.child(key).child("Minute").getValue(String.class);
                            String hour = dataSnapshot.child(key).child("Hour").getValue(String.class);
                            openDispDialogApt(name, phnum, conf, min, hour, year, month, day, key);
                            //getActivity().finish();
                            //startActivity(getActivity().getIntent());
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(getActivity().getApplicationContext(), "Error", Toast.LENGTH_LONG).show();

                    }
                });
            }
        });




        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialogApt();
            }
        });

            return view;
    }

    public void openDispDialogApt(String patnameapt, String phone, String conf, String min, String hour, int year, int month, int day, String key){  //onclick listview
        DispDialogApt dispDialog = new DispDialogApt ();
        dispDialog.patnameapt=patnameapt;
        dispDialog.phone=phone;
        dispDialog.conf=conf;
        dispDialog.min=min;
        dispDialog.hour=hour;
        dispDialog.key=key;
        dispDialog.month=month;
        dispDialog.year=year;
        dispDialog.day=day;
        FragmentTransaction ft = getChildFragmentManager().beginTransaction();
        dispDialog.show(ft, "dialog");
    }

    public void openDialogApt() {   //fab button
        ExampleDialogApt exDialogapt = new ExampleDialogApt();
        exDialogapt.mon=month;
        exDialogapt.yea=year;
        exDialogapt.dayy=day;
        exDialogapt.uidd=uid;
        FragmentTransaction ft = getChildFragmentManager().beginTransaction();
        exDialogapt.show(ft, "dialog");

    }

    public void getdialogapt(String patnameapt, String phone, int hour, int min, int year1,int month1, int day1,String uidd) {

        DatabaseReference mref1 = FirebaseDatabase.getInstance().getReference().child(uidd).child(Integer.toString(year1)).child("m"+Integer.toString(month1)).child("d"+Integer.toString(day1)).child("Appointments");
        String key=mref1.push().getKey();
        mref1.child(key).child("Name").setValue(patnameapt);
        mref1.child(key).child("Phone").setValue(phone);
        mref1.child(key).child("Minute").setValue(Integer.toString(min));
        mref1.child(key).child("Hour").setValue(Integer.toString(hour));
        mref1.child(key).child("Confirmed").setValue("0");

    }
}
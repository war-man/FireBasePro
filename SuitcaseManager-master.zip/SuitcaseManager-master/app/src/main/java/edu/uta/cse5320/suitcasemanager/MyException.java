package edu.uta.cse5320.suitcasemanager;

/**
 * Created by jeyan on 4/24/2017.
 */

public class MyException extends Exception {
    public MyException(String msg) {
        super(msg);
    }
}
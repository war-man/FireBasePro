package com.novumlogic.flightapp.Adapter;

import android.view.View;
import android.widget.TextView;

import com.bignerdranch.expandablerecyclerview.ViewHolder.ChildViewHolder;
import com.bignerdranch.expandablerecyclerview.ViewHolder.ParentViewHolder;
import com.novumlogic.flightapp.R;

/**
 * Created by NOVUMLOGIC-2 on 6/1/2017.
 */

public class TitleParentViewHolder extends ParentViewHolder {

    public TitleParentViewHolder(View itemView) {
        super(itemView);

    }
}

package com.novumlogic.flightapp;

/**
 * Created by NOVUMLOGIC-2 on 5/17/2017.
 */

public class CommonUtilities {

    //public static final String IMAGE_BASE_URL = "http://192.168.0.113:90/flightapp_images/";
    public static final String IMAGE_BASE_URL = "http://192.168.0.111:90/flightapp_images/";
}

package com.novumlogic.flightapp.Model;

/**
 * Created by NOVUMLOGIC-2 on 5/17/2017.
 */

public class Destination {

    int id;
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


}

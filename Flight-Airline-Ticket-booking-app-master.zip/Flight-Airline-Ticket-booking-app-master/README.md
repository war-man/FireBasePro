# Flight/Airline Ticket booking app
This project contains Static screen design of flight booking and information

It is with the reference of 
https://www.uplabs.com/posts/flight-app-concept-kit


To run this project with images follow below steps :

<B>1) Add all the images from images folder to your local directory </B>

<B>2) Do changes in the IMAGE_BASE_URL in CommonUtilities.java file according to local server URL (Ex: Localhost) </B>


![](images/1_splashscreen.jpg)
![](images/2_search_flow.jpg)
![](images/3_BookingFlow.jpg)
![](images/4_search_via map.jpg)
![](images/5_checkin flow.jpg)
![](images/6_TrackFlight.jpg)
![](images/7_MyFlight.jpg)
![](images/8_price_stats.jpg)


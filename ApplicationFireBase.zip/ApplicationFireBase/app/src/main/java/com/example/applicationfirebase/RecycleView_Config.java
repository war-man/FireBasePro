package com.example.applicationfirebase;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.List;

public class RecycleView_Config {
    FirebaseAuth firebaseAuth;
    private static FirebaseUser firebaseUser;
    private Context context;
    private BookAdapter mBookAdapter;
    public void setConfig(RecyclerView recyclerView,Context mcontext,List<Book> books,List<String> keys)
    {
        firebaseAuth = firebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        context = mcontext;
        mBookAdapter = new BookAdapter(books,keys);
        recyclerView.setLayoutManager(new LinearLayoutManager(mcontext));
        recyclerView.setAdapter(mBookAdapter);
    }
    class BookItemView extends RecyclerView.ViewHolder{
        private TextView mTitle;
        private TextView mAuthor;
        private TextView mISBN;
        private TextView mCategory;

        private String key;
        public BookItemView(ViewGroup parent)
        {
            super(LayoutInflater.from(context).inflate(R.layout.book_list_item,parent,false));

            mTitle = (TextView) itemView.findViewById(R.id.textView1);
            mAuthor =(TextView) itemView.findViewById(R.id.textView2);
            mISBN = (TextView) itemView.findViewById(R.id.textView3);
            mCategory = (TextView) itemView.findViewById(R.id.textView4);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(firebaseUser!= null)
                    {
                        Intent intent = new Intent(context,BookDetailsActivity.class);
                        intent.putExtra("key",key);
                        intent.putExtra("author",mAuthor.getText().toString());
                        intent.putExtra("title",mTitle.getText().toString());
                        intent.putExtra("ISBN",mISBN.getText().toString());
                        intent.putExtra("category",mCategory.getText().toString());

                        context.startActivity(intent);
                    }
                    else {
                        context.startActivity(new Intent(context,SigninActivity.class));
                    }
                }
            });
        }
        public void bind(Book book,String key)
        {
            mTitle.setText(book.getTitle());
            mAuthor.setText(book.getAuthor());
            mCategory.setText(book.getCategory_name());
            mISBN.setText(book.getIsbn());
            this.key = key;
        }
    }
    class BookAdapter extends RecyclerView.Adapter<BookItemView> {
        private List<Book> mBookList;
        private List<String> mKeys;

        public BookAdapter(List<Book> mBookList, List<String> mKeys) {
            this.mBookList = mBookList;
            this.mKeys = mKeys;
        }

        @NonNull
        @Override
        public BookItemView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new BookItemView(parent);
        }

        @Override
        public void onBindViewHolder(@NonNull BookItemView holder, int position) {
            holder.bind(mBookList.get(position), mKeys.get(position));
        }

        @Override
        public int getItemCount() {
            return mBookList.size();
        }
    }
    public static void logout(){
        firebaseUser = null;
    }
}

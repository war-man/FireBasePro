package com.example.applicationfirebase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;

public class BookDetailsActivity extends AppCompatActivity {

    EditText e1,e2,e3;
    Spinner s1;
    Button b1,b2,b3;

    private String key;
    private String author;
    private String title;
    private String Category;
    private String ISBN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_details);
        e1 = findViewById(R.id.edt1);
        e2 = findViewById(R.id.edt2);
        e3 = findViewById(R.id.edt3);
        s1 = findViewById(R.id.spn);
        b1 = findViewById(R.id.btnupdate);
        b2 = findViewById(R.id.btndelete);
        b3 = findViewById(R.id.btncancel);

        key = getIntent().getStringExtra("key");
        author = getIntent().getStringExtra("author");
        title = getIntent().getStringExtra("title");
        Category = getIntent().getStringExtra("category");
        ISBN = getIntent().getStringExtra("ISBN");

        e1.setText(author);
        e2.setText(title);
        e3.setText(ISBN);;
        s1.setSelection(getindexspinner(s1,Category));

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Book book = new Book();
                book.setAuthor(e1.getText().toString());
                book.setTitle(e2.getText().toString());
                book.setIsbn(e3.getText().toString());
                book.setCategory_name(s1.getSelectedItem().toString());
                new FirebaseDatabaseHelper().updatebook(key,book, new FirebaseDatabaseHelper.DataStatus() {
                    @Override
                    public void DataIsLoaded(List<Book> books, List<String> keys) {

                    }

                    @Override
                    public void DataIsInserted() {

                    }

                    @Override
                    public void DataIsUpdated() {
                        Toast.makeText(getApplicationContext(),"Sửa thành công",Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void DataIsDeleted() {

                    }
                });
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new FirebaseDatabaseHelper().deletebook(key,new FirebaseDatabaseHelper.DataStatus() {
                    @Override
                    public void DataIsLoaded(List<Book> books, List<String> keys) {

                    }

                    @Override
                    public void DataIsInserted() {

                    }

                    @Override
                    public void DataIsUpdated() {

                    }

                    @Override
                    public void DataIsDeleted() {
                        Toast.makeText(getApplicationContext(),"Xóa thành công",Toast.LENGTH_LONG).show();
                        finish();
                        return;
                    }
                });
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                return;
            }
        });
    }

    private int getindexspinner(Spinner spinner,String item)
    {
        int index = 0;
        for (int i = 0;i < spinner.getCount();i++){
            if(spinner.getItemAtPosition(i).equals(item)){
                index = i;
                break;
            }
        }
        return index;
    }
}

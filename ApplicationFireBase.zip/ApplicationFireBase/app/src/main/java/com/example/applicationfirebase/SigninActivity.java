package com.example.applicationfirebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SigninActivity extends AppCompatActivity {

    Button btnsign,btnregister,btnback;
    EditText edtemal,edtmk;
    ProgressBar pg;
    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);
        firebaseAuth = firebaseAuth.getInstance();
        edtemal = findViewById(R.id.edtemail);
        edtmk = findViewById(R.id.edtpass);
        btnsign = findViewById(R.id.btn3);
        btnregister = findViewById(R.id.btn4);
        btnback = findViewById(R.id.btn5);
        pg = findViewById(R.id.pg);
        pg.setVisibility(View.GONE);
        btnsign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isEmpty())
                    return;
                inprogress(true);
                firebaseAuth.signInWithEmailAndPassword(edtemal.getText().toString(),edtmk.getText().toString())
                        .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        Toast.makeText(getBaseContext(),"Succesfull",Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(SigninActivity.this,MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                        return;
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        inprogress(false);
                        Toast.makeText(getBaseContext(),"Fail",Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailID = edtemal.getText().toString();
                String paswd = edtmk.getText().toString();
                if (emailID.isEmpty()) {
                    edtemal.setError("Provide your Email first!");
                    edtemal.requestFocus();
                } else if (paswd.isEmpty()) {
                    edtmk.setError("Set your password");
                    edtmk.requestFocus();
                } else if (emailID.isEmpty() && paswd.isEmpty()) {
                    Toast.makeText(SigninActivity.this, "Fields Empty!", Toast.LENGTH_SHORT).show();
                } else if (!(emailID.isEmpty() && paswd.isEmpty())) {
                    firebaseAuth.createUserWithEmailAndPassword(emailID, paswd).addOnCompleteListener(SigninActivity.this, new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {

                            if (!task.isSuccessful()) {
                                Toast.makeText(SigninActivity.this.getApplicationContext(),
                                        "SignUp unsuccessful: " + task.getException().getMessage(),
                                        Toast.LENGTH_SHORT).show();
                            } else {
                                startActivity(new Intent(SigninActivity.this, MainActivity.class));
                            }
                        }
                    });
                } else {
                    Toast.makeText(SigninActivity.this, "Error", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                return;
            }
        });
    }
    private void inprogress(boolean x){
        if(x){
            pg.setVisibility(View.VISIBLE);
            btnback.setEnabled(false);
            btnsign.setEnabled(false);
            btnregister.setEnabled(false);
        }
        else {
            pg.setVisibility(View.GONE);
            btnback.setEnabled(true);
            btnregister.setEnabled(true);
            btnsign.setEnabled(true);
        }
    }
    private boolean isEmpty(){
        if(TextUtils.isEmpty(edtemal.getText().toString())){
            edtemal.setError("REQUIRED");
            return true;
        }
        if(TextUtils.isEmpty(edtmk.getText().toString())){
            edtmk.setError("REQUIRED");
            return true;
        }
        return false;
    }
}

package com.example.applicationfirebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firebaseAuth = firebaseAuth.getInstance();
        recyclerView = findViewById(R.id.list);
        new FirebaseDatabaseHelper().readbook(new FirebaseDatabaseHelper.DataStatus() {
            @Override
            public void DataIsLoaded(List<Book> books, List<String> keys) {
                findViewById(R.id.progressBar).setVisibility(View.GONE);
                new RecycleView_Config().setConfig(recyclerView,MainActivity.this,books,keys);
            }

            @Override
            public void DataIsInserted() {

            }

            @Override
            public void DataIsUpdated() {

            }

            @Override
            public void DataIsDeleted() {

            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
        getMenuInflater().inflate(R.menu.booklist_activity_menu,menu);
        if(firebaseUser != null)
        {
            menu.getItem(0).setVisible(true);
            menu.getItem(1).setVisible(false);
            menu.getItem(2).setVisible(true);
        }
        else {
            menu.getItem(0).setVisible(false);
            menu.getItem(1).setVisible(true);
            menu.getItem(2).setVisible(false);
        }
        return super.onCreateOptionsMenu(menu);
    }
/**
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
        getMenuInflater().inflate(R.menu.booklist_activity_menu,menu);
        if(firebaseUser != null)
        {
            menu.getItem(0).setVisible(true);
            menu.getItem(1).setVisible(false);
            menu.getItem(2).setVisible(true);
        }
        else {
            menu.getItem(0).setVisible(false);
            menu.getItem(1).setVisible(true);
            menu.getItem(2).setVisible(false);
        }
        return super.onPrepareOptionsMenu(menu);
    }
**/
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.newbook:
                startActivity(new Intent(this,NewBookActivity.class));
                return true;
            case R.id.signin:
                startActivity(new Intent(this,SigninActivity.class));
                return true;
            case R.id.signout:
                firebaseAuth.signOut();
                invalidateOptionsMenu();
                RecycleView_Config.logout();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

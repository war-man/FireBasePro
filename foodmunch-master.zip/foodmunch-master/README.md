# foodmunch
Food Munch is an android based food ordering application, database used is sqlite and firebase, status of the project not fully completed

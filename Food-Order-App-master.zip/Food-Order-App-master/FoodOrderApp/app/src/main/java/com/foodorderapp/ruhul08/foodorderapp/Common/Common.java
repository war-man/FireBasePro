package com.foodorderapp.ruhul08.foodorderapp.Common;

import com.foodorderapp.ruhul08.foodorderapp.Model.User;

public class Common {
    public static User currentUser;
}
